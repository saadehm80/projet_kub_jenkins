while true
do
  echo hello from linux
  sleep 2
done

