# kubernetes-devops-project

If you come from the Kubernetes training, you're in the right place ! :) 

Run the application :

docker-compose up -d
